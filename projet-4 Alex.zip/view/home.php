<?php
	$request = new Home();

	require('template/includes/home-view/post-feature.php');
?>
		
	<hr class="my-5" style="width:80%;background-color:#222;">
	
<?php
	require('template/includes/home-view/testimonial.php');
?>