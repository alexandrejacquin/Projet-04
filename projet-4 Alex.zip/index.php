<?php
require ('./controller/controller.php');

$controller = new Controller();
$controller->renderView();