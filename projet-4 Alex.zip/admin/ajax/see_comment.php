<?php
require_once '../model/dashboard.class.php';

$request = new Dashboard;
$request->validateCmt();