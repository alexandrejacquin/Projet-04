<?php
require_once '../model/post.class.php';

$request = new UpdatePost;
$request->deletePost($request);